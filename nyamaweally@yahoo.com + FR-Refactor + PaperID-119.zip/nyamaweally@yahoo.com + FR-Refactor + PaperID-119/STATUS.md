We are applying for "Available" badge for our paper entitled "Automated Recommendation of Software Refactorings based on Feature Requests" with reference number 119.

The applied badge is essential for our paper so as to notify the research community on the availability of data and source code of our approach to facilitate its further advancement. 