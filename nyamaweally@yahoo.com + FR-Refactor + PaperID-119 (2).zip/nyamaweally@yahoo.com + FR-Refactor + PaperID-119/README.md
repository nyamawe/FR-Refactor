# FR-Refactor
A machine-learning-based approach the recommends refactorings based on feature requests. The approach takes as input the past history of feature requests and applied refactorings. Consequently, binary and multi-label classifiers are trained to respectively predict whether refactoring is needed or not and reccommend the types refactoring required.  

