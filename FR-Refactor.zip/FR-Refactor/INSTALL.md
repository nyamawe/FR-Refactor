All the source code files are in src directory and they can be run in the order they appear in the directory. Note that, these are python files and therefore you would need python environment to run the files.

Further note that, you would need to redefine the directory path from which the training and testing dataset is populated.

If the source code run successful, the results will appear on the console.  